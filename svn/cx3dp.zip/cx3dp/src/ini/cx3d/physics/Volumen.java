package ini.cx3d.physics;

public interface Volumen {
	public double getVolume();
}
