package ini.cx3d.utilities.export;

import java.io.Serializable;

public interface IExporter extends Serializable{
	void process();
}
