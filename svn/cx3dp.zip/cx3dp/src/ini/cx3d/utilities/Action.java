package ini.cx3d.utilities;

public interface Action
{
	public void execute(String opts);
}
