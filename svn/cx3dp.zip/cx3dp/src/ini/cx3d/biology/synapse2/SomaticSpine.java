package ini.cx3d.biology.synapse2;


public class SomaticSpine extends Spine{


	
}
