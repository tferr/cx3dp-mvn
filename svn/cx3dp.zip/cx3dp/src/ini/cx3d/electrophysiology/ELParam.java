package ini.cx3d.electrophysiology;

public class ELParam {
	public static double timestep = 0.001; //in seconds!
}
