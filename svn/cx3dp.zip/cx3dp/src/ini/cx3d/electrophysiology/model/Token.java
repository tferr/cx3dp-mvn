package ini.cx3d.electrophysiology.model;

import java.awt.Color;

public interface Token{
	public Color getColor();
}
