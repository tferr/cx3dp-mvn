package ini.cx3d.spacialOrganisation.fixGrid;

import ini.cx3d.spacialOrganisation.ObjectReference;

public interface GridVisitor
{
	public void process(ObjectReference r);
	
}