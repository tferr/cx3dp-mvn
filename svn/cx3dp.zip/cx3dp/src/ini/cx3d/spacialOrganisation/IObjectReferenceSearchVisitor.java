package ini.cx3d.spacialOrganisation;


public interface IObjectReferenceSearchVisitor {

	public void visit(ObjectReference r);
}
