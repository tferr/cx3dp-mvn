package ini.cx3d.spacialOrganisation;

public class PMNotFoundException extends RuntimeException {

}
