package ini.cx3d.spacialOrganisation;

import java.util.Vector;

public class Xcut
{
	public Vector<PartitionManager> pmas = new Vector<PartitionManager>();
	public double x;
}