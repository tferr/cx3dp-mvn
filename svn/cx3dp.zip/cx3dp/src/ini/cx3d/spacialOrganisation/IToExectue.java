package ini.cx3d.spacialOrganisation;

public interface IToExectue {

	void execute();

	boolean check();

}
